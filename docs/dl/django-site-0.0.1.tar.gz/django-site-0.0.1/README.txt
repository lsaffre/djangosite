Lino README 
===========

About Lino
----------

Lino is a framework for writing desktop-like web applications 
using `Django <https://www.djangoproject.com/>`_
and `Sencha ExtJS <http://www.sencha.com/products/extjs/>`_.

More on http://lino-framework.org

Installation
------------

See http://lino-framework.org/admin/install.html




