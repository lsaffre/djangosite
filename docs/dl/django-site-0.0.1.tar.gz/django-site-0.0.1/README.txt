django-site README 
==================

About django-site
-----------------

More on http://site.lino-framework.org

Installation
------------

See http://site.lino-framework.org




